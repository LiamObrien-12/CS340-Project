from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

class AnimalShelter:
    def __init__(self, username, password):
        try:
            # Connect to hosted MongoDB for Apporto
            self.client = MongoClient(
                f"mongodb://{username}:{password}@nv-desktop-services.apporto.com:31239/animal_shelter?authSource=animal_shelter"
            )
            self.database = self.client["animal_shelter"]
            self.collection = self.database["outcomes"]
        except ConnectionFailure:
            raise Exception("Failed to connect to MongoDB")

    def create(self, data):
        if data:
            result = self.collection.insert_one(data)
            return result.acknowledged
        else:
            raise ValueError("Empty data provided to insert")

    def read(self, query):
        return list(self.collection.find(query))

    def update(self, query, new_data):
        if query and new_data:
            result = self.collection.update_many(query, {"$set": new_data})
            return result.modified_count
        else:
            raise ValueError("Missing query or update data")

    def delete(self, query):
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise ValueError("Missing query for delete operation")